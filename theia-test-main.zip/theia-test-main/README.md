<style>

.mermaidBg {
    background-color: white;
}

hr.niv1 {
    border-bottom: 1px solid orange;
}

hr.niv2 {
    border-bottom: 1px solid orange;
}

em {
    color: orange;
}

</style>

# THEIA

## 1. Dialogue BDJ avec l'API THEIA avec WebSocket (recommandé)
<hr class="niv1"/>

Dans cette version des échanges entre BDJ et THEIA c'est THEIA qui notifie BDJ de la fin du traitement d'annotation.  
Ce scénario d'échanges présente deux avantages par rapport au scénario en full REST API (décrit au paragraphe suivant) :
- On réduit les échanges réseaux (pas d'appels multiples au endpoint /api/annotated-legal-texts/:uid/status de l'API REST)
- Réduction du délai entre la fin du traitement d'annotation et la récupération du flux XML annoté

<div class="mermaidBg">

```mermaid
%%{
init: {
'theme': 'default',
'themeVariables': {
'primaryColor': '#f00'
}
}
}%%

sequenceDiagram
    autonumber
    participant BDJ as BDJ
    participant THEIA_REST as THEIA API<br/>(REST)
    participant THEIA_WS as THEIA API<br/>(Web Socket)
    BDJ -->> THEIA_WS: Request
    activate THEIA_WS
    activate BDJ
    THEIA_WS -->> BDJ: Hand Shake
    Note over BDJ: La connexion au WebSocket est établie.<br/>THEIA envoie l'ID de session du socket ouvert.
    THEIA_WS -->> BDJ: { "wsSessionId":"84c22297-861f-7f1c-6f7c-a3ccb79975c6" }
    par
        Note over BDJ, THEIA_REST: Envoi des N flux XML à annoter via l'API REST (asynchrone).
        loop
            Note over BDJ: Envoi du flux XML à annoter
            BDJ ->> THEIA_REST: POST /api/annotated-legal-texts?xmlDtd=JORF&annotation=FULL&wsWessionId=84c...75c6<br/>Request Body : application/xml
            activate THEIA_REST
            activate BDJ
            THEIA_REST ->> BDJ: { "uid":"c7078d54-40ac-4299-975a-0550b661696b", "xmlDtd":"JORF", "annotation":"FULL", "status":"RECIEVED", "wsSessionId":"84c...75c6" }
            deactivate BDJ
            deactivate THEIA_REST
            Note over BDJ: Notification de réception du flux à annoter
            THEIA_WS -->> BDJ: notification Web Socket<br/>{ "uid":"c7078d54-40ac-4299-975a-0550b661696b", "xmlDtd":"JORF", "annotation":"FULL", "status":"RECIEVED", "wsSessionId":"84c...75c6" }
        end
    and
        Note over BDJ, THEIA_REST: Réception des N flux XML annotés.
        loop
            Note over BDJ: Notification d'un flux annoté prêt à télécharger
            THEIA_WS -->> BDJ: notification Web Socket<br/>{ "uid":"c7078d54-40ac-4299-975a-0550b661696b", "xmlDtd":"JORF", "annotation":"FULL", "status":"PROCESSED", "wsSessionId":"84c...75c6" }
            Note over BDJ: Téléchargement du flux annoté
            BDJ ->> THEIA_REST: GET /api/annotated-legal-texts/c7078d54-40ac-4299-975a-0550b661696b
            activate THEIA_REST
            activate BDJ
            THEIA_REST ->> BDJ: XML annoté<br/>(Content-Type: application/xml)
            deactivate BDJ
            deactivate THEIA_REST
        end
    end
    Note over BDJ: Tous les flux sont annotés et téléchargés.<br/>Fermeture du Web Socket
    BDJ -->> THEIA_WS: close Web socket
    deactivate BDJ
    deactivate THEIA_WS
```

</div>

## 2. Dialogue BDJ avec l'API THEIA en full REST API (traitement séquentiel des flux XML)
<hr class="niv1"/>

BDJ tourne actuellement en java 6. Il n'y a pas de librairie permettant de se connecter au Web Socket.  
Pour pallier cette limitation nous décrivons dans le présent paragraphe une alternative au Web Socket fonctionnant en full REST API.  
En outre, BDJ présente une autre contrainte. Les flux XML (actes) ne peuvent être traités en parallèle. Le diagramme de séquence ci-après décrit en conséquence un traitement séquentiel des actes.

<div class="mermaidBg">

```mermaid
%%{
init: {
'theme': 'default',
'themeVariables': {
'primaryColor': '#f00'
}
}
}%%

sequenceDiagram
    autonumber
    participant BDJ as BDJ
    participant THEIA_REST as THEIA API<br/>(REST)

    loop
        Note over BDJ, THEIA_REST: Pour chaque flux XML (acte) à annoter.
        Note over BDJ: Envoi du flux XML (asynchrone)
        BDJ ->> THEIA_REST: POST /api/annotated-legal-texts?xmlDtd=JORF&annotation=FULL<br/>Request Body : application/xml
        activate THEIA_REST
        activate BDJ
        THEIA_REST ->> BDJ: { "uid":"c7078d54-40ac-4299-975a-0550b661696b", "xmlDtd":"JORF", "annotation":"FULL", "status":"RECIEVED" }
        deactivate BDJ
        deactivate THEIA_REST

        Note over BDJ: Vérification de l'avancement du traitement
        loop
            Note over BDJ, THEIA_REST: Vérification toutes les X secondes<br/>jusqu'à réception de "status":"PROCESSED"
            BDJ ->> THEIA_REST: GET /api/annotated-legal-texts/c7078d54-40ac-4299-975a-0550b661696b/status
            activate THEIA_REST
            activate BDJ
            THEIA_REST ->> BDJ: { "uid":"c7078d54-40ac-4299-975a-0550b661696b", "xmlDtd":"JORF", "annotation":"FULL", "status":"RECIEVED" }
            deactivate BDJ
            deactivate THEIA_REST
        end

        Note over BDJ: Téléchargement du flux XML annoté
        BDJ ->> THEIA_REST: GET /api/annotated-legal-texts/c7078d54-40ac-4299-975a-0550b661696b
        activate THEIA_REST
        activate BDJ
        THEIA_REST ->> BDJ: XML annoté<br/>(Content-Type: application/xml)
        deactivate BDJ
        deactivate THEIA_REST
    end
```

</div>

## 3. Configurations
<hr class="niv1"/>

### 3.1. Configuration de l'accès au service d'annotation

Pour configurer les accès au service d'annotation :
1. Ajouter en paramètre de la commande de lancement de l'application spring boot
```text
--spring.config.location=classpath:/application.yml,/path/to/theia/config/folder --spring.config.name=application-annotator
```

2. Créer dans le dossier <em>/path/to/theia/config/folder</em> le fichier <em>application-annotator.yml</em>
3. Fournir la configuation voulue dans le fichier <em>application-annotator.yml</em> comme ci-dessous
```yaml
theia:
  annotator:
    enabled: true
    api-url: "https://uri-to-rest-api"
    web-socket-url: "wss://uri-to-web-socket"
    user-name: "xxxxxxx"
    user-password: "yyyyyyy"
```

### 3.2. Sécuriser les accès (HTTPS / WSS)
<hr class="niv1"/>

Pour activer la sécurisation des protocoles https et wss :
1. Ajouter en paramètre de la commande de lancement de l'application spring boot
```text
--spring.config.location=classpath:/application.yml,/path/to/theia/config/folder --spring.config.name=application-ssl
```

Exemple windows :
```text
--spring.config.location=classpath:/application.yml,file:///D:/PROJECTS.dila/THEIA.config/ --spring.config.name=application-ssl
```

2. Créer dans le dossier <em>/path/to/theia/config/folder</em> le fichier <em>application-ssl.yml</em> 
3. Fournir la configuation voulue dans le fichier <em>application-ssl.yml</em> comme ci-dessous
```yaml
server:
  ssl:
    enabled: true
    key-store-type: PKCS12
    key-store: /path/to/theia/key-store/theia.p12
    key-store-password: xxxxxxx
    key-alias: theia
  port: 8443
```
4. Créer le fichier <em>theia.p12</em>

https://www.baeldung.com/openssl-self-signed-cert

Certificat autosigné avec keytool
```bash
keytool -genkeypair -alias theia -keyalg RSA -keysize 4096 -storetype PKCS12 -keystore theia.p12 -validity 3650 -storepass xxxxxxx
```

### 3.3. Cloisonner la configuration

Il est possible de découper la configuration en plusieurs fichiers dédiés. Par exemple :
- Un fichier application-annotator.yml pour les accès au service d'annotation
- Un fichier application-ssl.yml pour la sécurisation des accès à THEIA API

Puis on démarre l'application en fournissant en paramètre les deux fichiers de configuration séparés par une virgule :
```text
--spring.config.name=application-annotator,application-ssl
```

