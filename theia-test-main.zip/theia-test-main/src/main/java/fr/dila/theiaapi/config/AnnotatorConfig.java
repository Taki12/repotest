package fr.dila.theiaapi.config;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "theia.annotator")
@Data
public class AnnotatorConfig {
    @NotNull
    private String webSocketUrl;
    @NotNull
    private String apiUrl;
    @NotNull
    private String userName;
    @NotNull
    private String userPassword;
}
