package fr.dila.theiaapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.http.HttpClient;
import java.net.http.WebSocket;

@Configuration
public class WebSocketBuilderConfiguration {

    @Bean
    public WebSocket.Builder annotatorWebSocketBuilder() {

        return HttpClient.newBuilder()
                .build()
                .newWebSocketBuilder();
    }
}
