package fr.dila.theiaapi.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class IAServiceException extends Exception {

    public IAServiceException(final String message, final Exception exception) {
        super(message, exception);
    }
}
