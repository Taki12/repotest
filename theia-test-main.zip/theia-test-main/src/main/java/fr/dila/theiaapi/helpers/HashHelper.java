package fr.dila.theiaapi.helpers;

import lombok.experimental.UtilityClass;
import org.springframework.util.DigestUtils;

@UtilityClass
public class HashHelper {

    private static final String HASH_NAME = "SHA3-256";

    public static String uid(final byte[] data) {
        return DigestUtils.md5DigestAsHex(data);
    }
}
