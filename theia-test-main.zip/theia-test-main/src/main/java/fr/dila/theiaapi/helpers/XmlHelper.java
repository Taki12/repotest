package fr.dila.theiaapi.helpers;

import lombok.experimental.UtilityClass;
import net.sf.saxon.TransformerFactoryImpl;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

@UtilityClass
public class XmlHelper {

    public static byte[] xmlTransform(final byte[] xmlBytes, final InputStream xslt) throws TransformerException {

        return xmlTransform(new ByteArrayInputStream(xmlBytes), xslt);
    }

    public static byte[] xmlTransform(final InputStream xmlStream, final InputStream xslt) throws TransformerException {

        // Configure XSLT transformer.
        final TransformerFactoryImpl tf = new TransformerFactoryImpl();
        final TransformerHandler th = tf.newTransformerHandler(new StreamSource(xslt));
        final Transformer transformer = th.getTransformer();

        // Handle transform.
        final StringWriter outWriter = new StringWriter();
        transformer.transform(new StreamSource(xmlStream), new StreamResult(outWriter));
        return outWriter.getBuffer().toString().getBytes(StandardCharsets.UTF_8);
    }
}
