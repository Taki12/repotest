package fr.dila.theiaapi.models.emuns;

public enum AnnotationModeEnum {
    FULL,
    LINKS_ONLY
}
