package fr.dila.theiaapi.models.emuns;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum DocumentUnitTypeEnum {
    @JsonProperty("titre")
    TITRE,
    @JsonProperty("visas")
    VISAS,
    @JsonProperty("article")
    ARTICLE,
    @JsonProperty("texte-non-structure")
    TEXTE_NON_STRUCTURE,
}
