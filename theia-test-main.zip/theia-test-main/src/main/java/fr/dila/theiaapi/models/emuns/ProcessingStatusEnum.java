package fr.dila.theiaapi.models.emuns;

public enum ProcessingStatusEnum {
    RECIEVED,
    PROCESSED,
    FAILED;
}
