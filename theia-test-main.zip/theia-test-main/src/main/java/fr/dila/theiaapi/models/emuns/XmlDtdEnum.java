package fr.dila.theiaapi.models.emuns;

public enum XmlDtdEnum {
    JORF,
    KALI;
}
