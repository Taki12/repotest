package fr.dila.theiaapi.models.payloads;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.emuns.ProcessingStatusEnum;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TheiaPayloadAnnotationDto {
    private String uid;
    private String legalText;
    private XmlDtdEnum xmlDtd;
    private String annotatedLegalText;
    @JsonProperty("annotation")
    private AnnotationModeEnum annotationMode;
    private ProcessingStatusEnum status;
    private String wsSessionId;

    public TheiaPayloadAnnotationStatusDto toPayloadAnnotationStatus() {

        final TheiaPayloadAnnotationStatusDto payloadAnnotationStatus = new TheiaPayloadAnnotationStatusDto();
        payloadAnnotationStatus.setWsSessionId(getWsSessionId());
        payloadAnnotationStatus.setUid(getUid());
        payloadAnnotationStatus.setStatus(getStatus());
        payloadAnnotationStatus.setAnnotationMode(getAnnotationMode());
        payloadAnnotationStatus.setXmlDtd(getXmlDtd());
        return payloadAnnotationStatus;
    }
}
