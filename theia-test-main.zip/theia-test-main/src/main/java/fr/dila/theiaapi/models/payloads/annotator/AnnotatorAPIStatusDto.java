package fr.dila.theiaapi.models.payloads.annotator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.ProcessingStatusEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Map;

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnnotatorAPIStatusDto {

    private enum AnnotatorStatusEnum {
        started(ProcessingStatusEnum.RECIEVED),
        completed(ProcessingStatusEnum.PROCESSED),
        failed(ProcessingStatusEnum.FAILED),
        unknown(null);

        private final ProcessingStatusEnum processingStatus;
        AnnotatorStatusEnum(ProcessingStatusEnum processingStatus) {
            this.processingStatus = processingStatus;
        }

        public ProcessingStatusEnum toProcessingStatus() {
            return processingStatus;
        }

        public static AnnotatorStatusEnum numToValue(final int number) {
            return switch (number) {
                case -1 -> failed;
                case 0 -> started;
                case 1 -> completed;
                default -> unknown;
            };
        }
    }

    @JsonProperty(required = true)
    private String uid;
    @JsonProperty(required = true)
    private XmlDtdEnum xmlDtd;
    @JsonProperty(value = "annotation", required = true)
    private AnnotationModeEnum annotationMode;
    @JsonProperty(required = true)
    private String wsSessionId;
    private AnnotatorStatusEnum status;

    @JsonProperty("status")
    private void unpackStatusFromNestedObject(Map<String, String> status) {
        this.status = AnnotatorStatusEnum.numToValue(Integer.parseInt(status.get("status")));
    }

    public TheiaPayloadAnnotationStatusDto toAnnotationPayload() {
        final TheiaPayloadAnnotationStatusDto payload = new TheiaPayloadAnnotationStatusDto();
        payload.setUid(getUid());
        payload.setXmlDtd(getXmlDtd());
        payload.setWsSessionId(getWsSessionId());
        payload.setAnnotationMode(getAnnotationMode());
        payload.setStatus(getStatus().toProcessingStatus());
        return payload;
    }
}
