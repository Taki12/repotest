package fr.dila.theiaapi.models.payloads.annotator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.ProcessingStatusEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Map;

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnnotatorWSStatusDto {

    private enum PythagoriaStatusEnum {
        started(ProcessingStatusEnum.RECIEVED),
        completed(ProcessingStatusEnum.PROCESSED),
        failed(ProcessingStatusEnum.FAILED);

        private final ProcessingStatusEnum processingStatus;
        PythagoriaStatusEnum(ProcessingStatusEnum processingStatus) {
            this.processingStatus = processingStatus;
        }

        public ProcessingStatusEnum toProcessingStatus() {
            return processingStatus;
        }
    }

    @JsonProperty(required = true)
    private String uid;
    @JsonProperty(required = true)
    private XmlDtdEnum xmlDtd;
    @JsonProperty(value = "annotation", required = true)
    private AnnotationModeEnum annotationMode;
    @JsonProperty(required = true)
    private String wsSessionId;
    private PythagoriaStatusEnum status;

    @JsonProperty("pythagoria")
    private void unpackStatusFromNestedObject(Map<String, Object> pythagoria) {
        final Map<String, Object> workflow = (Map<String, Object>) pythagoria.get("workflow");
        final Map<String, String> task1 = (Map<String, String>) workflow.get("task1");
        status = PythagoriaStatusEnum.valueOf(task1.get("status"));
    }

    public TheiaPayloadAnnotationStatusDto toAnnotationPayload() {
        final TheiaPayloadAnnotationStatusDto payload = new TheiaPayloadAnnotationStatusDto();
        payload.setUid(getUid());
        payload.setXmlDtd(getXmlDtd());
        payload.setWsSessionId(getWsSessionId());
        payload.setAnnotationMode(getAnnotationMode());
        payload.setStatus(getStatus().toProcessingStatus());
        return payload;
    }
}
