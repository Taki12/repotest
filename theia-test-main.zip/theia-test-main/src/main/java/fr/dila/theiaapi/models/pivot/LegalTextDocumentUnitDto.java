package fr.dila.theiaapi.models.pivot;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
import fr.dila.theiaapi.models.emuns.DocumentUnitTypeEnum;
import lombok.Data;

@Data
public class LegalTextDocumentUnitDto {
    private String id;
    private DocumentUnitTypeEnum type;
    private String number;
    @JacksonXmlCData()
    private String content;
    private PythagoriaDto pythagoria;
}
