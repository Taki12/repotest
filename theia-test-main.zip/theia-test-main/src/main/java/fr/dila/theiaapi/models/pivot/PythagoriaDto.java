package fr.dila.theiaapi.models.pivot;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PythagoriaDto {

    private enum TaskEnum {
        @JsonProperty("classification_modif_autonome")
        CLASSIFICATION_MODIF_AUTONOME
    }

    private TaskEnum task;
    private PythagoriaResultDto result;
    @JacksonXmlProperty(localName = "liens_citation")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonProperty("liens_citation")
    private List<PythagoriaLienCitationDto> liensCitation;
}
