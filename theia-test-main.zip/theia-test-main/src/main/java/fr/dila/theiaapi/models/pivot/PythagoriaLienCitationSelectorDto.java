package fr.dila.theiaapi.models.pivot;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PythagoriaLienCitationSelectorDto {

    private String startContainer;
    private String endContainer;
    private long startOffset;
    private long endOffset;
}
