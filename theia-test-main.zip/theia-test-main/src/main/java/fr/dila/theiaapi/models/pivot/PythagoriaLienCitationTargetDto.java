package fr.dila.theiaapi.models.pivot;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = { "article", "class", "confidence", "country", "language", "level", "title" })
public class PythagoriaLienCitationTargetDto {

    private String cid;
}
