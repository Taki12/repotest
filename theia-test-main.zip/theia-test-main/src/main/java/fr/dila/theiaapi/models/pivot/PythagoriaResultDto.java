package fr.dila.theiaapi.models.pivot;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PythagoriaResultDto {

    private enum ArticleTypeEnum {
        @JsonProperty("modifiant")
        MODIFIANT,
        @JsonProperty("autonome")
        AUTONOME,

    }

    @JsonProperty("type_art")
    private ArticleTypeEnum articleType;
}
