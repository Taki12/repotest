package fr.dila.theiaapi.services;

import fr.dila.theiaapi.exceptions.IAServiceException;
import fr.dila.theiaapi.exceptions.NotFoundUidException;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import fr.dila.theiaapi.models.pivot.AnnotatorPivotDto;
import org.springframework.stereotype.Service;
import rx.Observer;
import rx.subjects.PublishSubject;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.net.http.WebSocket;

@Service
public abstract class AnnotatorService {

    final PublishSubject<TheiaPayloadAnnotationStatusDto> subject = PublishSubject.create();
    public abstract TheiaPayloadAnnotationStatusDto postLegalText(byte[] xmlData, XmlDtdEnum xmlDtd, AnnotationModeEnum annotationMode, String wsSessionId) throws IAServiceException;
    public abstract AnnotatorPivotDto toPivotJson(byte[] xmlData, XmlDtdEnum xmlDtd, AnnotationModeEnum annotationMode) throws IAServiceException, IOException, TransformerException;
    public abstract byte[] getAnnotatedLegalText(final String uid) throws NotFoundUidException;
    public abstract byte[] getAnnotatedLegalTextHtml(final String uid) throws NotFoundUidException, IOException, TransformerException;
    public abstract TheiaPayloadAnnotationStatusDto getStatus(final String uid) throws NotFoundUidException;
    public final void subscribe(Observer<TheiaPayloadAnnotationStatusDto> observer) {
        subject.subscribe(observer);
    }
    public abstract void openAnnotatorWebSocket() throws IAServiceException;
}
