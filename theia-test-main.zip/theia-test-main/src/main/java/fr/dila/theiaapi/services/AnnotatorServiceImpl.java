package fr.dila.theiaapi.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import fr.dila.theiaapi.helpers.HashHelper;
import fr.dila.theiaapi.config.AnnotatorConfig;
import fr.dila.theiaapi.exceptions.IAServiceException;
import fr.dila.theiaapi.exceptions.NotFoundUidException;
import fr.dila.theiaapi.helpers.XmlHelper;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.pivot.LegalTextDto;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorAPIStatusDto;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorWSAuthenticatedDto;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorWSStatusDto;
import fr.dila.theiaapi.models.pivot.AnnotatorPivotDto;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorAPITokenDto;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorWSAuthenticateDto;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import fr.dila.theiaapi.models.pivot.PythagoriaLienCitationSelectorDto;
import fr.dila.theiaapi.models.pivot.RequestDto;
import lombok.extern.log4j.Log4j2;
import net.sf.saxon.TransformerFactoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URI;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

@Service
@ConditionalOnProperty(value="theia.annotator.enabled", havingValue = "true", matchIfMissing = true)
@Log4j2
public class AnnotatorServiceImpl extends AnnotatorService implements WebSocket.Listener {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AnnotatorConfig annotatorConfig;
    private final WebSocket.Builder annotatorWebSocketBuilder;
    private final AnnotatorWebClient annotatorWebClient;
    private final Set<WebSocket> authenticatedWebSockets = new HashSet<>();
    private static final String XSLT_JORF_PREPARE = "classpath:xslt/jorf.01-prepare.xsl";
    private static final String XSLT_JORF_TO_PIVOT = "classpath:xslt/jorf.02-to-pivot.xsl";
    private static final String XSLT_JORF_TO_HTML = "classpath:xslt/jorf.04-to-html.xsl";
    private static final String XSLT_JORF_MERGE_ANNOTATIONS = "classpath:xslt/jorf.03-merge-annotations.xsl";
    private final ResourceLoader resourceLoader;
    private WebSocket annotatorWebSocket;

    public AnnotatorServiceImpl(
            @Autowired
            final AnnotatorConfig annotatorConfig,
            @Autowired
            @Qualifier("annotatorWebSocketBuilder")
            final WebSocket.Builder annotatorWebSocketBuilder,
            @Autowired
            final AnnotatorWebClient annotatorWebClient,
            @Autowired
            final ResourceLoader resourceLoader
    ) {
        this.annotatorConfig = annotatorConfig;
        this.annotatorWebSocketBuilder = annotatorWebSocketBuilder;
        this.annotatorWebClient = annotatorWebClient;
        this.resourceLoader = resourceLoader;
    }

    @Override
    public TheiaPayloadAnnotationStatusDto postLegalText(byte[] xmlData, XmlDtdEnum xmlDtd, AnnotationModeEnum annotationMode, String wsSessionId) throws IAServiceException {

        try {

            final AnnotatorPivotDto document = toPivotJson(xmlData, xmlDtd, annotationMode);
            document.getRequest().setWsSessionId(wsSessionId);
            return annotatorWebClient.postLegalTextForFullAnnotation(document);
        } catch (RuntimeException | IOException | TransformerException e) {

            log.error("IA ANNOTATION POST ERROR");
            log.catching(e);
            throw new IAServiceException("", e);
        }
    }

    @Override
    public AnnotatorPivotDto toPivotJson(byte[] xmlData, XmlDtdEnum xmlDtd, AnnotationModeEnum annotationMode) throws IAServiceException, IOException, TransformerException {

        final AnnotatorPivotDto document = new AnnotatorPivotDto();

        final byte[] jorfPrepared = jorfXmlPrepare(xmlData);
        final byte[] xmlDecision = jorfXmlToPivot(jorfPrepared);
        final LegalTextDto legalText = new XmlMapper().readValue(xmlDecision, LegalTextDto.class);

        document.setXmlBase64(new String(Base64.getEncoder().encode(jorfPrepared)));
        final RequestDto request = new RequestDto();
        request.setUid(HashHelper.uid(xmlData));
        request.setXmlDtd(xmlDtd);
        request.setAnnotationMode(annotationMode);
        document.setRequest(request);
        document.setLegalText(legalText);
        return document;
    }

    @Override
    public byte[] getAnnotatedLegalText(final String uid) throws NotFoundUidException {

        AnnotatorPivotDto pivotDto = annotatorWebClient.getAnnotatedLegalText(uid);
        if (pivotDto == null) {
            throw new NotFoundUidException();
        }

        // .
        pivotDto.getLegalText().getDocumentUnits().forEach(article -> {
            if (article.getPythagoria() != null && article.getPythagoria().getResult() != null) {

                log.info("[{}]->[{}]", article.getId(), article.getPythagoria().getResult().getArticleType());
            }
        });

        // Annotations as XML.
        try {
            return insertLinkAnnotations(pivotDto);

//            final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
//            final Path trace = Path.of("D:\\TMP\\THEIA\\annotations-" + formatter.format(new Date()) + "-" + pivotDto.getRequest().getUid() + ".xml");
//            FileUtils.copyInputStreamToFile(new ByteArrayInputStream(legalTextAsXml), trace.toFile());
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }

//        return Base64.getDecoder().decode(pivotDto.getXmlBase64());
    }

    @Override
    public byte[] getAnnotatedLegalTextHtml(String uid) throws NotFoundUidException, IOException, TransformerException {
        final byte[] annotatedXml = getAnnotatedLegalText(uid);
        return XmlHelper.xmlTransform(annotatedXml, resourceLoader.getResource(XSLT_JORF_TO_HTML).getInputStream());
    }

    @Override
    public TheiaPayloadAnnotationStatusDto getStatus(final String uid) throws NotFoundUidException {

        AnnotatorAPIStatusDto payload = annotatorWebClient.getStatus(uid);
        if (payload == null) {
            throw new NotFoundUidException();
        }

        return payload.toAnnotationPayload();
    }

    @Override
    public void openAnnotatorWebSocket() throws IAServiceException {

        try {

            // Open Web Socket.
            if (annotatorWebSocket == null) {

                annotatorWebSocketBuilder
                        .buildAsync(URI.create(annotatorConfig.getWebSocketUrl()), this)
                        .get();
//            } else if (annotatorWebSocket.isInputClosed() || annotatorWebSocket.isOutputClosed()) {
//
//                annotatorWebSocket.sendClose(CloseStatus.SERVER_ERROR.getCode(), "");
            }

        } catch (InterruptedException e) {

            // TODO : comprendre ce qui est fait ici.
            Thread.currentThread().interrupt();
            throw new IAServiceException("Annotator Web Socket opening failed.", e);
        } catch (ExecutionException e) {

            throw new IAServiceException("Annotator Web Socket opening failed.", e);
        }
    }

    @Override
    public final void onOpen(final WebSocket webSocket) {
        log.info("ANNOTATOR SOCKET OPENED.");
        annotatorWebSocket = webSocket;
        AnnotatorAPITokenDto token = annotatorWebClient.getToken();
        AnnotatorWSAuthenticateDto wsSubscription = new AnnotatorWSAuthenticateDto();
        wsSubscription.setToken(token.getToken());
        try {
            webSocket.sendText(objectMapper.writeValueAsString(wsSubscription), true);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        WebSocket.Listener.super.onOpen(webSocket);
    }

    @Override
    public CompletionStage<?> onText(
            final WebSocket webSocket,
            final CharSequence data,
            boolean last
    ) {
        try {
            if (!authenticatedWebSockets.contains(webSocket)) {
                log.info("ANNOTATOR SOCKET AUTHENTICATED.");
                final AnnotatorWSAuthenticatedDto payloadDto = objectMapper.readValue(data.toString(), AnnotatorWSAuthenticatedDto.class);
                authenticatedWebSockets.add(webSocket);
            } else {

                log.info("ANNOTATOR SOCKET NOTIFICATION [{}].", data);
                final AnnotatorWSStatusDto payloadDto = objectMapper.readValue(data.toString(), AnnotatorWSStatusDto.class);
                subject.onNext(payloadDto.toAnnotationPayload());
            }
        } catch (JsonProcessingException e) {
            log.error("WebSocket message parse error [{}].", data);
        }
        return WebSocket.Listener.super.onText(webSocket, data, last);
    }

    @Override
    public final CompletionStage<?> onClose(final WebSocket webSocket, final int statusCode, final String reason) {

        log.info("ANNOTATOR SOCKET CLOSED.");
        annotatorWebSocket = null;
        return WebSocket.Listener.super.onClose(webSocket, statusCode, reason);
    }

    public byte[] jorfXmlPrepare(final InputStream xmlStream) throws TransformerException, IOException {

        return XmlHelper.xmlTransform(xmlStream, resourceLoader.getResource(XSLT_JORF_PREPARE).getInputStream());
    }

    private byte[] jorfXmlPrepare(final byte[] xmlData) throws TransformerException, IOException {

        return jorfXmlPrepare(new ByteArrayInputStream(xmlData));
    }

    private byte[] jorfXmlToPivot(final byte[] xmlData) throws TransformerException, IOException {

        return XmlHelper.xmlTransform(xmlData, resourceLoader.getResource(XSLT_JORF_TO_PIVOT).getInputStream());
    }

    public byte[] insertLinkAnnotations(AnnotatorPivotDto pivotDto) throws TransformerException, IOException {

        AnnotatorServiceImpl.normalizeXPath(pivotDto);

        final InputStream xslt = resourceLoader.getResource(XSLT_JORF_MERGE_ANNOTATIONS).getInputStream();
        final byte[] jorfAsXml = Base64.getDecoder().decode(pivotDto.getXmlBase64());
        final byte[] annotatedArticlesAsXml = new XmlMapper().writeValueAsBytes(pivotDto.getLegalText());

        // Configure XSLT transformer.
        final TransformerFactoryImpl tf = new net.sf.saxon.TransformerFactoryImpl();
        final TransformerHandler th = tf.newTransformerHandler(new StreamSource(xslt));
        final Transformer transformer = th.getTransformer();
        transformer.setParameter("allAnnotatedUnits", new StreamSource(new StringReader(new String(annotatedArticlesAsXml))));

        // Handle transform.
        final StringWriter outWriter = new StringWriter();
        transformer.transform(new StreamSource(new ByteArrayInputStream(jorfAsXml)), new StreamResult(outWriter));
        return outWriter.getBuffer().toString().getBytes(StandardCharsets.UTF_8);
    }

    private static void normalizeXPath(final AnnotatorPivotDto annotatorPivotDto) {
        annotatorPivotDto.getLegalText().getDocumentUnits().forEach(documentUnit -> {
            Optional.ofNullable(documentUnit.getPythagoria()).ifPresent(pythagoriaDto -> pythagoriaDto.getLiensCitation().forEach(lienCitation -> {
                final PythagoriaLienCitationSelectorDto selectorDto = lienCitation.getSelector();
                final String startXpath = selectorDto.getStartContainer();
                final String endXpath = selectorDto.getEndContainer();
                selectorDto.setStartContainer(normalizeXPath(startXpath));
                selectorDto.setEndContainer(normalizeXPath(endXpath));
            }));
        });
    }

    private static String normalizeXPath(final String xPath) {
        return xPath
                .replaceAll("/p([/$])", "/p[1]$1")
                .replaceAll("^(.+)/text\\(\\)$", "$1");
    }
}
