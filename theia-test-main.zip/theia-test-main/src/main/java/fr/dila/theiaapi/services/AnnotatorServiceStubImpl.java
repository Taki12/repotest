package fr.dila.theiaapi.services;

import fr.dila.theiaapi.exceptions.IAServiceException;
import fr.dila.theiaapi.exceptions.NotFoundUidException;
import fr.dila.theiaapi.helpers.HashHelper;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationDto;
import fr.dila.theiaapi.models.emuns.ProcessingStatusEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import fr.dila.theiaapi.models.pivot.AnnotatorPivotDto;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.stereotype.Service;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
@ConditionalOnMissingBean(AnnotatorServiceImpl.class)
public class AnnotatorServiceStubImpl extends AnnotatorService {

    private final Map<String, TheiaPayloadAnnotationDto> payloads = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private final Random random = new Random();

    @Override
    public TheiaPayloadAnnotationStatusDto postLegalText(byte[] xmlData, XmlDtdEnum xmlDtd, AnnotationModeEnum annotationMode, String wsSessionId) {

        try {
            Thread.sleep(500);

            // Notify RECIEVED.
            final TheiaPayloadAnnotationDto payload = new TheiaPayloadAnnotationDto();
            payload.setUid(HashHelper.uid(xmlData) + "-BOUCHON");
            payload.setWsSessionId(wsSessionId);
            payload.setLegalText(new String(xmlData));
            payload.setXmlDtd(xmlDtd);
            payload.setAnnotationMode(annotationMode);
            payload.setStatus(ProcessingStatusEnum.RECIEVED);
            payloads.put(payload.getUid(), payload);
            subject.onNext(payload.toPayloadAnnotationStatus());

            // Notify PROCESSED.
            scheduler.schedule(() -> {

                // Notify PROCESSED.
                payload.setAnnotatedLegalText(payload.getLegalText());
                payload.setStatus(ProcessingStatusEnum.PROCESSED);
                subject.onNext(payload.toPayloadAnnotationStatus());

            }, random.nextLong(10) + 3, TimeUnit.SECONDS);

            return payload.toPayloadAnnotationStatus();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public AnnotatorPivotDto toPivotJson(byte[] xmlData, XmlDtdEnum xmlDtd, AnnotationModeEnum annotationMode) throws IAServiceException, IOException, TransformerException {
        return null;
    }

    @Override
    public byte[] getAnnotatedLegalText(final String uid) throws NotFoundUidException {

        final TheiaPayloadAnnotationDto payload = payloads.get(uid);
        if (payload == null) {
            throw new NotFoundUidException();
        }

        return payload.getAnnotatedLegalText().getBytes(StandardCharsets.UTF_8);
    }

    @Override
    public byte[] getAnnotatedLegalTextHtml(String uid) throws NotFoundUidException {
        return new byte[0];
    }

    @Override
    public TheiaPayloadAnnotationStatusDto getStatus(final String uid) throws NotFoundUidException {

        final TheiaPayloadAnnotationDto payload = payloads.get(uid);
        if (payload == null) {
            throw new NotFoundUidException();
        }

        return payload.toPayloadAnnotationStatus();
    }

    @Override
    public void openAnnotatorWebSocket() throws IAServiceException {
        // no op
    }
}
