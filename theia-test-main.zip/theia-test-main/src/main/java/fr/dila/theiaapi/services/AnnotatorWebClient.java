package fr.dila.theiaapi.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.json.JsonMapper;
import fr.dila.theiaapi.config.AnnotatorConfig;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorAPIStatusDto;
import fr.dila.theiaapi.models.pivot.AnnotatorPivotDto;
import fr.dila.theiaapi.models.payloads.annotator.AnnotatorAPITokenDto;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
@Log4j2
public class AnnotatorWebClient {

    private final boolean theiaTrace;
    private final JsonMapper jsonMapper = new JsonMapper();
    private final AnnotatorConfig iaServicesConfig;
    private final WebClient.Builder webClientBuilder;

    public AnnotatorWebClient(
            @Value("${theia.trace}")
            boolean theiaTrace,
            final AnnotatorConfig iaServicesConfig,
            @Qualifier("annotatorWebClientBuilder")
            final WebClient.Builder webClientBuilder
    ) {
        this.theiaTrace = theiaTrace;
        this.iaServicesConfig = iaServicesConfig;
        this.webClientBuilder = webClientBuilder;
    }

//    public WebClient.RequestHeadersSpec<?> buildGETWebClientRequestHeadersSpec(final String uri) {
//
//        return buildGETWebClientRequestHeadersSpec(uri, new Object[0]);
//    }

    public TheiaPayloadAnnotationStatusDto postLegalTextForFullAnnotation(AnnotatorPivotDto document) throws JsonProcessingException {

        if (theiaTrace) {
            final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
            final Path trace = Path.of("D:\\TMP\\THEIA\\post-" + formatter.format(new Date()) + "-" + document.getRequest().getUid() + ".json");
            try {
                FileUtils.copyInputStreamToFile(new ByteArrayInputStream(jsonMapper.writeValueAsBytes(document)), trace.toFile());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return webClientBuilder
                .baseUrl(iaServicesConfig.getApiUrl())
                .build()
                .post()
                .uri("/actions_conso/{uid}.json", document.getRequest().getUid())
                .headers(h -> {
                    h.setBasicAuth(iaServicesConfig.getUserName(), iaServicesConfig.getUserPassword());
                    h.setAccept(List.of(MediaType.APPLICATION_JSON));
                    h.setContentType(MediaType.APPLICATION_JSON);
                })
                .body(BodyInserters.fromValue(jsonMapper.writeValueAsBytes(document)))
                .retrieve()
                .bodyToMono(TheiaPayloadAnnotationStatusDto.class)
                .block();
    }

    public AnnotatorPivotDto getAnnotatedLegalText(final String uid) {

        return webClientBuilder
                .baseUrl(iaServicesConfig.getApiUrl())
                .build()
                .get()
                .uri("/processed/{uid}.json", uid)
                .headers(h -> {
                    h.setBasicAuth(iaServicesConfig.getUserName(), iaServicesConfig.getUserPassword());
                    h.setAccept(List.of(MediaType.APPLICATION_JSON));
                })
                .retrieve()
                .bodyToMono(AnnotatorPivotDto.class)
                .block();
    }

    public AnnotatorAPIStatusDto getStatus(final String uid) {

        return webClientBuilder
                .baseUrl(iaServicesConfig.getApiUrl())
                .build()
                .get()
                .uri("/status/{uid}.json", uid)
                .headers(h -> {
                    h.setBasicAuth(iaServicesConfig.getUserName(), iaServicesConfig.getUserPassword());
                    h.setAccept(List.of(MediaType.APPLICATION_JSON));
                })
                .retrieve()
                .bodyToMono(AnnotatorAPIStatusDto.class)
                .block();
    }

    public AnnotatorAPITokenDto getToken() {

        return webClientBuilder
                .baseUrl(iaServicesConfig.getApiUrl())
                .build()
                .get()
                .uri("/getJWToken")
                .headers(h -> {
                    h.setBasicAuth(iaServicesConfig.getUserName(), iaServicesConfig.getUserPassword());
                    h.setAccept(List.of(MediaType.APPLICATION_JSON));
                })
                .retrieve()
                .bodyToMono(AnnotatorAPITokenDto.class)
                .block();
    }
}
