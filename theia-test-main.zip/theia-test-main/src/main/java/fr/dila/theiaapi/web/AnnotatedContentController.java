package fr.dila.theiaapi.web;

import fr.dila.theiaapi.exceptions.IAServiceException;
import fr.dila.theiaapi.exceptions.NotFoundUidException;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import fr.dila.theiaapi.services.AnnotatorService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.Optional;

@Controller
@RequestMapping(value = "/api/annotated-legal-texts")
@Log4j2
public class AnnotatedContentController {

    private final AnnotatorService annotatorService;

    public AnnotatedContentController(
            @Autowired
            AnnotatorService annotatorService
    ) {
        this.annotatorService = annotatorService;
    }

    @PostMapping(value = { "", "/" }, consumes = MimeTypeUtils.APPLICATION_XML_VALUE, produces = MimeTypeUtils.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<TheiaPayloadAnnotationStatusDto> postLegalText(
            @RequestBody byte[] xmlData,
            @RequestParam(name = "wsSessionId", required = false) String wsSessionId,
            @RequestParam(name = "xmlDtd") XmlDtdEnum xmlDtd,
            @RequestParam(name = "annotation", required = false) AnnotationModeEnum annotationMode
    ) throws IAServiceException, IOException, TransformerException {
        final TheiaPayloadAnnotationStatusDto statusPayload = annotatorService.postLegalText(xmlData, xmlDtd, Optional.ofNullable(annotationMode).orElse(AnnotationModeEnum.FULL), wsSessionId);
        return new ResponseEntity<>(statusPayload, HttpStatus.OK);
    }

    @GetMapping(value = "/{uid}", produces = MimeTypeUtils.APPLICATION_XML_VALUE)
    @ResponseBody
    public ResponseEntity<byte[]> getAnnotatedLegalText(@PathVariable(name = "uid") String uid) throws NotFoundUidException {
        return new ResponseEntity<>(annotatorService.getAnnotatedLegalText(uid), HttpStatus.OK);
    }

    @GetMapping(value = "/{uid}/status", produces = MimeTypeUtils.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<TheiaPayloadAnnotationStatusDto> getStatus(@PathVariable(name = "uid") String uid) throws NotFoundUidException {
        final TheiaPayloadAnnotationStatusDto statusPayload = annotatorService.getStatus(uid);
        return new ResponseEntity<>(statusPayload, HttpStatus.OK);
    }

    @GetMapping(value = "/{uid}/html", produces = MimeTypeUtils.TEXT_HTML_VALUE)
    @ResponseBody
    public ResponseEntity<byte[]> getAnnotatedLegalTextHtml(@PathVariable(name = "uid") String uid) throws NotFoundUidException, IOException, TransformerException {
        return new ResponseEntity<>(annotatorService.getAnnotatedLegalTextHtml(uid), HttpStatus.OK);
    }
}
