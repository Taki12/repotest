package fr.dila.theiaapi.web;

import fr.dila.theiaapi.exceptions.IAServiceException;
import fr.dila.theiaapi.models.emuns.AnnotationModeEnum;
import fr.dila.theiaapi.models.emuns.XmlDtdEnum;
import fr.dila.theiaapi.models.pivot.AnnotatorPivotDto;
import fr.dila.theiaapi.services.AnnotatorService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.Optional;

@Controller
@RequestMapping(value = "/api/tests")
@Log4j2
public class TestsController {
    private final AnnotatorService annotatorService;

    public TestsController(
            @Autowired
            AnnotatorService annotatorService
    ) {
        this.annotatorService = annotatorService;
    }

    @PostMapping(value = { "/pivot-json" }, consumes = MimeTypeUtils.APPLICATION_XML_VALUE, produces = MimeTypeUtils.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<AnnotatorPivotDto> jsonPivot(
            @RequestBody byte[] xmlData,
            @RequestParam(name = "xmlDtd") XmlDtdEnum xmlDtd,
            @RequestParam(name = "annotation", required = false) AnnotationModeEnum annotationMode
    ) throws IAServiceException, IOException, TransformerException {
        final AnnotatorPivotDto document = annotatorService.toPivotJson(xmlData, xmlDtd, Optional.ofNullable(annotationMode).orElse(AnnotationModeEnum.FULL));
//        document.setXmlBase64(null);
        return new ResponseEntity<>(document, HttpStatus.OK);
    }
}
