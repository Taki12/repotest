package fr.dila.theiaapi.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.dila.theiaapi.exceptions.IAServiceException;
import fr.dila.theiaapi.models.payloads.TheiaPayloadAnnotationStatusDto;
import fr.dila.theiaapi.models.payloads.TheiaPayloadWSConnectedDto;
import fr.dila.theiaapi.services.AnnotatorService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import rx.Observer;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Log4j2
public class WebSocketHandler extends TextWebSocketHandler implements Observer<TheiaPayloadAnnotationStatusDto> {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Map<String, WebSocketSession> wsSessions = new ConcurrentHashMap<>();
    private final AnnotatorService annotatorService;

    public WebSocketHandler(
            @Autowired
            AnnotatorService annotatorService) {

        // Subscribe to IA annotation service.
        this.annotatorService = annotatorService;
        annotatorService.subscribe(this);
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message)
    throws InterruptedException, IOException {
        // Annotations are only requested from REST API endpoints.
        // WebSocket is only used to notify when annotations are completed.
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session)
    throws Exception {

        try {

            // If not already opened, open a socket with annotator services.
            annotatorService.openAnnotatorWebSocket();
        } catch (IAServiceException e) {
            log.error("IA WebSocket connection failed.");
            session.sendMessage(new TextMessage("ERROR"));
            session.close(CloseStatus.SERVER_ERROR);
            return;
        }

        log.info("WebSocket: connection established.");

        // .
        wsSessions.put(session.getId(), session);

        // Send message 'is connected'.
        final TheiaPayloadWSConnectedDto payloadWSConnected = new TheiaPayloadWSConnectedDto();
        payloadWSConnected.setWsSessionId(session.getId());
        session.sendMessage(new TextMessage(objectMapper.writeValueAsString(payloadWSConnected)));
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {

        log.info("WebSocket: connection closed.");

        // .
        wsSessions.remove(session.getId());
    }

    @Override
    public void onCompleted() {
        // no op.
    }

    @Override
    public void onError(Throwable throwable) {
        // no op.
    }

    @Override
    public void onNext(TheiaPayloadAnnotationStatusDto statusPayload) {

        wsSessions.entrySet().stream()
                .filter(entry -> {
                    if (statusPayload.getWsSessionId() == null) {
                        return true;
                    }
                    return statusPayload.getWsSessionId().equals(entry.getKey());
                }).map(Map.Entry::getValue)
                .forEach(wsSession -> sendPayload(wsSession, statusPayload));
    }

    private void sendPayload(WebSocketSession wsSession, TheiaPayloadAnnotationStatusDto statusPayload) {

        if (wsSession.isOpen()) {

            try {
                wsSession.sendMessage(new TextMessage(objectMapper.writeValueAsBytes(statusPayload)));
            } catch (RuntimeException | IOException e) {
                try {
                    wsSession.close(CloseStatus.SERVER_ERROR);
                } catch (RuntimeException | IOException ignored) {
                    // no op.
                }
            }
        }
    }
}