<style>

h3 {
    color: orange
}

hr {
    border: 1px solid orange
}

em.tag {
    color: green;
}

em.cas {
    color: orange;
}

</style>


### CAS-001: référence à une loi
(<em class="cas">loi n° 2021-1031 du 4 août 2021 de programmation relative au développement solidaire et à la lutte contre les inégalités mondiales</em>)

tag:  <em class="tag">CORPS_ANNEXE / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220101-001501/JOP20220001_010.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_010.xml)

Acte du JORF: [Décret du 30 décembre 2021 portant approbation des statuts de la société Expertise France](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044806327) (NOR : EAEM2137499D)

```text
<p align="center">
	<br>Article 1er</br>
	<br>Forme</br>
</p>
<p align="left">
	<br>En application de la loi n° 2021-1031 du 4 août 2021 de programmation relative au développement solidaire et à la lutte contre les inégalités mondiales, il est formé par l'associé unique,</br>
</p>
```

---

### CAS-002: référence à un article de l'acte lui-même
(<em class="cas">article 12.1</em>)

tag:  <em class="tag">CORPS_ANNEXE / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220101-001501/JOP20220001_010.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_010.xml)

Acte du JORF: [Décret du 30 décembre 2021 portant approbation des statuts de la société Expertise France](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044806327) (NOR : EAEM2137499D)

```text
<p align="left">
	<br>- de son Président, nommé dans les conditions prévues à l'article 12.1 des présents statuts ;</br>
	<br>- de deux députés et de deux sénateurs désignés par les commissions permanentes chargées des affaires étrangères de l'Assemblée Nationale et du Sénat ;</br>
	...
</p>
```

---

### CAS-003: référence à un article de code préfixé par L.
(<em class="cas">L. 225-43 du Code de commerce</em>)

tag:  <em class="tag">CORPS_ANNEXE / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220101-001501/JOP20220001_010.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_010.xml)

Acte du JORF: [Décret du 30 décembre 2021 portant approbation des statuts de la société Expertise France](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044806327) (NOR : EAEM2137499D)

```text
<p align="center">
	<br>Article 15</br>
	<br>Conventions réglementées</br>
</p>
<p align="left">
	<br>Toute convention intervenant, directement ou par personne interposée entre la Société et le Président de son Conseil d'administration, l'un de ses dirigeants, son associé unique doit être portée à la connaissance des commissaires aux comptes dans le mois de sa conclusion.</br>
	<br>Le Président du conseil d'administration ou l'intéressé doit, dans le mois de la conclusion d'une convention, en aviser le commissaire aux comptes par lettre recommandée avec demande d'avis de réception, si la Société en est dotée.</br>
	<br>Le Président du Conseil d'administration ou le commissaire aux comptes, si la Société en est dotée, présente à l'associé unique ou aux associés un rapport sur la conclusion et l'exécution des conventions au cours de l'exercice écoulé. L'associé unique ou les associés statuent sur ce rapport lors de la décision statuant sur les comptes de cet exercice.</br>
	<br>Les interdictions prévues à l'article L. 225-43 du Code de commerce s'appliquent au Président du Conseil d'administration et aux dirigeants de la Société.</br>
</p>
```

---

### CAS-004: référence à une série d'articles de code
(<em class="cas">article R. 435-10, R. 435-14 et R. 436-15 du code de l'environnement</em>)

tag:  <em class="tag">CORPS_ANNEXE / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220101-001501/JOP20220001_015.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_015.xml)

Acte du JORF: [Arrêté du 20 décembre 2021 portant approbation du modèle de cahier des charges pour l'exploitation du droit de pêche de l'État dans les eaux mentionnées à l'article L.435-1 du code de l'environnement](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044806473) (NOR : TREL2136537A)

```text
<br>Conformément à l'article R. 435-10, R. 435-14 et R. 436-15 du code de l'environnement, les licences attribuées aux membres de l'association agréée des pêcheurs professionnels en eau douce précisent la nature, les dimensions, le nombre et les conditions d'utilisation du ou des engins et filets que leurs titulaires sont autorisés à utiliser.</br>
```

---

### CAS-005: référence à un intervalle d'articles de code
(<em class="cas">L. 435-1 à L. 435-3 ... du code de l'environnement</em>)

tag:  <em class="tag">CORPS_ANNEXE / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220101-001501/JOP20220001_015.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_015.xml)

Acte du JORF: [Arrêté du 20 décembre 2021 portant approbation du modèle de cahier des charges pour l'exploitation du droit de pêche de l'État dans les eaux mentionnées à l'article L.435-1 du code de l'environnement](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044806473) (NOR : TREL2136537A)

```text
<br>- aux articles L. 435-1 à L. 435-3, L. 436-4, L. 436-10, R. 212-22, R. 435-2 à R. 435-33, R. 436-24, R. 436-25 et R. 436-69 du code de l'environnement ;</br>
```

---

### CAS-006: référence à un article de code préfixé par A.
(<em class="cas">article A.12 du code du domaine de l'État</em>)

tag:  <em class="tag">CORPS_ANNEXE / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220101-001501/JOP20220001_010.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_010.xml)

Acte du JORF: [Décret du 30 décembre 2021 portant approbation des statuts de la société Expertise France](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044806327) (NOR : EAEM2137499D)

```text
<br>- à l'article A.12 du code du domaine de l'État ;</br>
```

---

### CAS-007: référence à un "texte de journal officel" dans un CORPS/TEXTE_NON_STRUCTURE
(<em class="cas">Journal officiel n° 0007 du 9 janvier 2022, texte n° 37</em>)

tag:  <em class="tag">CORPS / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220111-001501/JOP20220008_012.xml](../resources/data-full/jorf/2022/20220111-001501/JOP20220008_012.xml)

Acte du JORF: [Décret du 7 janvier 2021 portant nomination (Cour des comptes) (rectificatif)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044901840) (NOR : CPTP2137327Z)

```text
<p align="left">
	<br>Rectificatif au Journal officiel n° 0007 du 9 janvier 2022, texte n° 37 :</br>
	<br>Dans le titre et au premier alinéa, au lieu de : « 7 janvier 2021 », lire : « 7 janvier 2022 ».</br>
</p>
```

---

### CAS-008: référence à un article de code dans un CORPS/TEXTE_NON_STRUCTURE
(<em class="cas">article L. 2261-15 du code du travail</em>)

tag:  <em class="tag">CORPS / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220218-003501/JOP20220041_085.xml](../resources/data-full/jorf/2022/20220218-003501/JOP20220041_085.xml)

Acte du JORF: [Avis relatif à l'extension d'un accord territorial (Champagne-Ardenne) conclu dans le cadre de la convention collective nationale des employés, techniciens et agents de maîtrise des travaux publics](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045185874) (NOR : MTRT2205032V)

```text
<br>En application de l'article L. 2261-15 du code du travail, la ministre du travail, de l'emploi et de l'insertion envisage de prendre un arrêté tendant à rendre obligatoires, pour tous les employeurs et tous les salariés entrant dans son champ d'application, les stipulations de l'accord ci-après indiqué.</br>
```

---

### CAS-009: arrêté dans VISAS
(<em class="cas">arrêté du 14 octobre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire </em>)

tag:  <em class="tag">CORPS / VISAS</em>

file: [jorf/2022/20220101-001501/JOP20220001_046.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_046.xml)

Acte du JORF: [Arrêté du 31 décembre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044807086) (NOR : SSAZ2139335A)

Liens vers :
- [Arrêté du 14 octobre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044206592) (NOR : SSAZ2131168A)

Remarque :
- Plusieurs « arrêté du 14 octobre 2021 » sont publié dans le [JORF n° 0241 du 15 octobre 2021](https://www.legifrance.gouv.fr/jorf/jo/2021/10/15/0241)

```text
<p align="left">
    <br>Le ministre des solidarités et de la santé,</br>
    <br>Vu la directive (UE) 2015/1535 du Parlement européen et du Conseil du 9 septembre 2015 prévoyant une procédure d'information dans le domaine des réglementations techniques et des règles relatives aux services de la société de l'information, et notamment la notification n° 2021/916/F ;</br>
    <br>Vu le code de la santé publique, notamment ses articles L. 3131-1 et L. 3131-16 ;</br>
    <br>Vu la loi n° 2021-689 du 31 mai 2021 modifiée relative à la gestion de la sortie de crise sanitaire ;</br>
    <br>Vu la loi n° 2021-1040 du 5 août 2021 modifiée relative à la gestion de la crise sanitaire ;</br>
    <br>Vu l'arrêté du 1er juin 2021 modifié prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire ;</br>
    <br>Vu l'arrêté du 14 octobre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire ;</br>
    <br>Vu l'arrêté du 10 novembre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire ;</br>
    <br>Considérant que, dans le cadre de la campagne de vaccination pour les enfants âgés de 5 à 11 ans, il y a lieu, d'une part, de permettre aux pharmaciens d'officine de reconstituer et délivrer les seringues destinées à ce public et, d'autre part, de prévoir que l'étiquette apposée sur chaque seringue mentionne l'indication pédiatrique ou adulte du vaccin qu'elle contient ;</br>
    <br>Considérant que dans un contexte de forte circulation du virus, il est nécessaire de maintenir l'offre de vaccination à un niveau élevé, notamment pour assurer les rappels du vaccin ; qu'il y a lieu, en conséquence, de prévoir la participation à la campagne vaccinale des détenteurs de la formation « prévention et secours civiques de niveau 1 » (PSC1) ;</br>
    <br>Considérant qu'il y a lieu d'apporter des clarifications rédactionnelles s'agissant de l'interdiction, de portée générale, du commerce électronique des autotests dont la vente au détail a été autorisée en dehors des officines de pharmacie ainsi que du régime de rémunération des personnes autorisées à vacciner en pharmacie après 20h et le dimanche ;</br>
    <br>Considérant que la situation sanitaire doit rester sous surveillance renforcée en Guadeloupe et en Guyane, que la reprise épidémique nécessite de réaliser un suivi effectif et consistant de l'évolution de l'épidémie, que les taux de vaccination restent très faibles sur ces territoires et les systèmes de santé très fragiles, qu'il y a lieu, en conséquence, de maintenir de manière transitoire la gratuité des tests de dépistage de la Covid-19 en Guadeloupe et en Guyane,</br>
    <br>Arrête :</br>
</p>
```

---

### CAS-009: arrêté « susvisé »
(<em class="cas">article 2 de l'arrêté du 14 octobre 2021 susvisé</em>)

tag:  <em class="tag">CORPS / ARTICLE_TEXTE</em>

file: [jorf/2022/20220101-001501/JOP20220001_046.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_046.xml)

Acte du JORF: [Arrêté du 31 décembre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044807086) (NOR : SSAZ2139335A)

Liens vers :
- [Arrêté du 14 octobre 2021 modifiant l'arrêté du 1er juin 2021 prescrivant les mesures générales nécessaires à la gestion de la sortie de crise sanitaire](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044206592) (NOR : SSAZ2131168A)

Remarque :
- Plusieurs « arrêté du 14 octobre 2021 » sont publié dans le [JORF n° 0241 du 15 octobre 2021](https://www.legifrance.gouv.fr/jorf/jo/2021/10/15/0241)

```text
<p align="left">
    <br>I. - Le II de l'article 2 de l'arrêté du 14 octobre 2021 susvisé ainsi modifié :</br>
    <br>1° Après les mots : « à cette date » sont insérés les mots : « et les territoires de la Guadeloupe et de la Guyane ;</br>
    <br>2° Après les mots : « entrent en vigueur », est inséré le mot : « , respectivement, »</br>
    <br>3° Les mots : « , s'agissant de la Guadeloupe, le 1er janvier 2022 » sont remplacés par les mots : « le 15 février 2022 » ;</br>
    <br>II. - Au I de l'article 4 de l'arrêté du 10 novembre 2021 susvisé, le premier alinéa est complété par les mots : « ainsi qu'en Guadeloupe et en Guyane » et au second alinéa, les mots : « , à l'exception de la Guadeloupe où elle prend fin le 31 décembre 2021 » sont remplacés par les mots : « et le 15 février 2022 en ce qui concerne la Guadeloupe et la Guyane ».</br>
</p>
```

---

### CAS-010: règlement « susvisé » (Référence au Journal officiel de l'Union européenne)
(<em class="cas">point 3.1 de l'annexe 13 du règlement CEE-ONU n° 13 susvisé</em>)

tag:  <em class="tag">CORPS / ARTICLE_TEXTE</em>

file: [jorf/2022/20220101-001501/JOP20220001_054.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_054.xml)

Acte du JORF: [Arrêté du 27 décembre 2021 portant application du décret n° 2021-1806 autorisant l'expérimentation de la circulation de véhicules de transport routier de betteraves dépassant le poids total roulant autorisé prévu par le code de la route](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044807182) (NOR : TRAT2137849A)

Liens vers :
- [Règlement no 13 de la Commission économique pour l'Europe des Nations unies (CEE-ONU) —
  Prescriptions uniformes relatives à l'homologation des véhicules des catégories M, N et O en ce qui
  concerne le freinage [2016/194]](https://eur-lex.europa.eu/legal-content/FR/TXT/PDF/?uri=OJ:JOL_2016_042_R_0001&from=FR) (EUR-Lex)

Remarque :
- Référence au « Journal officiel de l'Union européenne »

```text
<p align="left">
    <br>- masse maximale autorisée en service de 19 tonnes au minimum ;</br>
    <br>- masse maximale autorisée de l'ensemble en service de 48 tonnes au minimum ;</br>
    <br>- système de freinage avec antiblocage (ABS) tel que défini au point 3.1 de l'annexe 13 du règlement CEE-ONU n° 13 susvisé ;</br>
    <br>- motorisation type Euro V ou supérieure.</br>
</p>
```

---

### CAS-011: article de code dans NOTICE
(<em class="cas">article R. 312-4 du code de la route</em>)

tag:  <em class="tag">CORPS / NOTICE</em>

file: [jorf/2022/20220101-001501/JOP20220001_054.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_054.xml)

Acte du JORF: [Arrêté du 27 décembre 2021 portant application du décret n° 2021-1806 autorisant l'expérimentation de la circulation de véhicules de transport routier de betteraves dépassant le poids total roulant autorisé prévu par le code de la route](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044807182) (NOR : TRAT2137849A)

Liens vers :
- [Article R312-4 du code de la route](https://www.legifrance.gouv.fr/codes/id/LEGIARTI000043907798/2023-04-03)

Remarque :
- Référence au « Journal officiel de l'Union européenne »

```text
<p align="left">
    <br>Publics concernés : entreprises de transport routier de marchandises, entreprises de récolte et de transformation de la betterave sucrière, gestionnaires de voirie routière.</br>
    <br>Objet : cet arrêté précise les conditions dans lesquelles certains ensembles de véhicules sont autorisés à dépasser le poids total roulant fixé à l'article R. 312-4 du code de la route dans le cadre de l'expérimentation prévue par le décret n° 2021-1806 du 23 décembre 2021.</br>
    <br>Entrée en vigueur : le lendemain de sa publication.</br>
    <br>Notice : l'arrêté fixe les conditions de mise en œuvre de l'expérimentation : périodes concernées, spécifications des véhicules et des itinéraires, conditions particulières de circulation et méthode de collecte des données d'évaluation.</br>
    <br>Références : le présent arrêté peut être consulté sur le site Légifrance (https://www.legifrance.gouv.fr).</br>
</p>
```

---

### CAS-012: cas « complexe » dans les VISAS
(<em class="cas">accord du 17 avril 2019 de révision de la convention collective du personnel des industries du cartonnage</em>)  
(<em class="cas">convention collective nationale susvisée</em>)  
(<em class="cas">annexe du 17 avril 2019 à l'accord de révision susvisé</em>)  
(<em class="cas">avis publié au Journal officiel du 21 juin 2019</em>)  

tag:  <em class="tag">CORPS / VISAS</em>

file: [jorf/2022/20220101-001501/JOP20220001_075.xml](../resources/data-full/jorf/2022/20220101-001501/JOP20220001_075.xml)

Acte du JORF: [Arrêté du 17 décembre 2021 portant extension d'un accord et de son annexe, conclus dans le cadre de la convention collective nationale du personnel des industries du cartonnage (n° 489)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044807298) (NOR : MTRT2119674A)

Liens vers :
- [xxxx](https://www.legifrance.gouv.fr)


```text
<p align="left">
    <br>La ministre du travail, de l'emploi et de l'insertion,</br>
    <br>Vu le code du travail, notamment son article L. 2261-15 ;</br>
    <br>Vu l'arrêté du 2 août 1971 et les arrêtés successifs portant extension de la convention collective nationale du personnel des industries du cartonnage du 9 janvier 1969, et des textes qui l'ont complétée ou modifiée ;</br>
    <br>Vu l'arrêté du 14 septembre 1973 et les arrêtés successifs portant extension de la convention collective nationale des instruments à écrire et des industries connexes du 13 février 1973 et des textes qui l'ont complétée ou modifiée ;</br>
    <br>Vu l'arrêté du 23 janvier 2019 portant fusion et élargissement de champs conventionnels ;</br>
    <br>Vu l'accord du 17 avril 2019 de révision de la convention collective du personnel des industries du cartonnage, conclu dans le cadre de la convention collective nationale susvisée ;</br>
    <br>Vu l'annexe du 17 avril 2019 à l'accord de révision susvisé ;</br>
    <br>Vu la demande d'extension présentée par les organisations signataires ;</br>
    <br>Vu l'avis publié au Journal officiel du 21 juin 2019 ;</br>
    <br>Vu les avis recueillis au cours de l'enquête ;</br>
    <br>Vu l'avis motivé de la Commission nationale de la négociation collective, de l'emploi et de la formation professionnelle (sous-commission des conventions et accords) rendu lors de la séance du 1er juillet 2021,</br>
    <br>Arrête :</br>
</p>
```

---

### CAS-013: décision dans VISAS
(<em class="cas">décision du 8 février 2022 portant nomination d'un rapporteur permanent des services d'instruction de l'Autorité de la concurrence</em>)

tag:  <em class="tag">CORPS / VISAS</em>

file: [jorf/2022/20220220-001501/JOP20220043_068.xml](../resources/data-full/jorf/2022/20220220-001501/JOP20220043_068.xml)

Acte du JORF: [Décision du 14 février 2022 portant nomination d'un rapporteur permanent des services d'instruction de l'Autorité de la concurrence](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045191155) (NOR : ACOR2205155S)

Liens vers :
- [Décision du 8 février 2022 portant nomination d'un rapporteur permanent des services d'instruction de l'Autorité de la concurrence](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045161193) (NOR : ACOR2204472S)

```text
<p align="left">
    <br>Le rapporteur général,</br>
    <br>Vu le livre IV du code du commerce, notamment ses articles L. 461-4 et R. 461-3 ;</br>
    <br>Vu l'alinéa 2 de l'article 16 de la loi n° 2017-55 du 20 janvier 2017 portant statut général des autorités administratives indépendantes et des autorités publiques indépendantes ;</br>
    <br>Vu l'arrêté ministériel du 7 janvier 2021 portant reconduction de la nomination de M. Stanislas MARTIN aux fonctions de rapporteur général de l'Autorité de la concurrence ;</br>
    <br>Vu la décision du 8 février 2022 portant nomination d'un rapporteur permanent des services d'instruction de l'Autorité de la concurrence,</br>
    <br>Décide :</br>
</p>
```

---

### CAS-014: références (article X septies, article X octies)
(<em class="cas">articles 265 septies et 265 octies du code des douanes</em>)  

tag:  <em class="tag">CORPS / VISAS</em>

file: [jorf/2022/20220302-005902/JOP20220051_054.xml](../resources/data-full/jorf/2022/20220302-005902/JOP20220051_054.xml)

Acte du JORF: [Arrêté du 22 février 2022 portant modification de l'arrêté du 4 février 2022 pris en application des dispositions des articles 265 septies et 265 octies du code des douanes](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045279794) (NOR : CCPD2206063A)

Liens vers :
- [Article 265 septies](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000042910663)
- [Article 265 octies](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000033469186)

```text
<p align="left">
    <br>Le ministre délégué auprès du ministre de l'économie, des finances et de la relance, chargé des comptes publics,</br>
    <br>Vu le code des douanes, notamment ses articles 265 septies et 265 octies ;</br>
    <br>Vu le code d'imposition sur les biens et services, notamment ses articles L. 312-53 et L. 312-51 ;</br>
    <br>Vu l'arrêté du 4 février 2022 pris en application des dispositions des articles 265 septies et 265 octies du code des douanes,</br>
    <br>Arrête :</br>
</p>
```

---

### CAS-015: références « inversées » (« notamment ses articles »)
(<em class="cas">code d'imposition sur les biens et services, notamment ses articles L. 312-53 et L. 312-51</em>)

tag:  <em class="tag">CORPS / VISAS</em>

file: [jorf/2022/20220302-005902/JOP20220051_054.xml](../resources/data-full/jorf/2022/20220302-005902/JOP20220051_054.xml)

Acte du JORF: [Arrêté du 22 février 2022 portant modification de l'arrêté du 4 février 2022 pris en application des dispositions des articles 265 septies et 265 octies du code des douanes](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045279794) (NOR : CCPD2206063A)

Liens vers :
- [Article L312-53 du Code des impositions sur les biens et services](https://www.legifrance.gouv.fr/codes/id/LEGIARTI000044603737)
- [Article L312-51 du Code des impositions sur les biens et services](https://www.legifrance.gouv.fr/codes/id/LEGIARTI000044603741)

```text
<p align="left">
    <br>Le ministre délégué auprès du ministre de l'économie, des finances et de la relance, chargé des comptes publics,</br>
    <br>Vu le code des douanes, notamment ses articles 265 septies et 265 octies ;</br>
    <br>Vu le code d'imposition sur les biens et services, notamment ses articles L. 312-53 et L. 312-51 ;</br>
    <br>Vu l'arrêté du 4 février 2022 pris en application des dispositions des articles 265 septies et 265 octies du code des douanes,</br>
    <br>Arrête :</br>
</p>
```

---

### CAS-016: lister tous les cas numéros d'articles

cf site web 

https://reflex.sne.fr/codes-officiels



