<style>

h3 {
    color: orange
}

hr {
    border: 1px solid orange
}

em.tag {
    color: green;
}

em.cas {
    color: orange;
}

</style>

## Commentaires généraux

Analyse des article modifiants ou partiellement modifiants :  
- CORPS > ARTICLE_TEXTE : voir cas du gros fichier !!
- CORPS_ANNEXE > ARTICLE_TEXTE : OK
- CORPS > TEXTE_NON_STRUCTURE : il existe des cas d'articles modifiants dans des textes non structurés mais il s'agit de textes très spécifiques (conventions, contrats...)
- CORPS_ANNEXE > TEXTE_NON_STRUCTURE :




## Cas de tests

### COPRS > Texte structuré

tag:  <em class="tag">CORPS/ARTICLE_TEXTE</em>


### COPRS > Texte non structuré

tag:  <em class="tag">CORPS/TEXTE_NON_STRUCTURE</em>


### ANNEXE > Texte structuré

tag:  <em class="tag">CORPS_ANNEXE/ARTICLE_TEXTE</em>


### ANNEXE > Texte non structuré

tag:  <em class="tag">CORPS_ANNEXE/TEXTE_NON_STRUCTURE</em>


---

---

---

tag:  CORPS_ANNEXE/TEXTE_NON_STRUCTURE
file: 20220101-001501/JOP20220001_010.xml
################################################################################
contient des articles non structurés (paragraphe <p>).
QUESTION: les articles portés par CORPS_ANNEXE/TEXTE_NON_STRUCTURE sont-ils toujours autonomes ou peuvent-ils être modifiants ?

---

tag:  CORPS/TEXTE_NON_STRUCTURE
file: 20220101-001501/JOP20220001_010.xml
################################################################################

QUESTION: les articles portés par CORPS/TEXTE_NON_STRUCTURE sont-ils toujours autonomes ou peuvent-ils être modifiants ?



- Dans le contexte CORPS_ANNEXE, le tag TEXTE_NON_STRUCTURE est régulièrement porteur d'articles : ces articles sont-ils toujours autonomes ou peuvent-ils être modifiants ?
- Dans le contexte CORPS, le tag TEXTE_NON_STRUCTURE semble ne jamais être porteur d'article. Est-ce bien le cas ? Peut-on y trouver des articles modifiants ou partiellement autonomes ? Ce tag a-t-il une fonction particulière ?


---

---

---


### CAS-xxx: Article modifiant dans les annexes + Pas de version consolidée dans LEGI du texte visé

tag:  <em class="tag">CORPS_ANNEXE/ARTICLE_TEXTE</em>

file: [jorf/2022/20220105-003502/JOP20220003_023.xml](../resources/data-full/jorf/2022/20220105-003502/JOP20220003_023.xml)

Acte du JORF: [Décret n° 2022-5 du 3 janvier 2022 approuvant le premier avenant à la convention passée entre l'Etat et la Société ADELAC pour la conception, la construction, l'entretien, l'exploitation et la maintenance de la section Saint-Julien-en-Genevois-Villy-le-Pelloux de l'autoroute A41 ainsi que les modifications du cahier des charges annexées à cet avenant](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044833794?init=true)

Modifications portant sur :
- [Décret du 27 octobre 2005 approuvant la convention de concession passée entre l'Etat et la société ADELAC pour la conception, la construction, l'entretien, l'exploitation et la maintenance de la section Saint-Julien-en-Genevois-Villy-le-Pelloux de l'autoroute A 41 et le cahier des charges annexé à cette convention](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000000636199?init=true) (Existe uniquement en version originale, pas de version consolidée dans LEGI)


Commentaire du DIRE :  
Ces textes ne sont pas consolidé actuellement, ils sont trop compliqués à suivre et ce sont des contrats très spécifiques.  
Ils ne sont actuellement pas traités par manque de temps.  
Mais grâce à THEIA on pourra le faire.  

```text
<ARTICLE_NUM>25</ARTICLE_NUM>
<ARTICLE_TEXTE>
 <p align="left">
	<br>L'article 25 est ainsi modifié :</br>
	<br>1° Au paragraphe 25.3, le dernier alinéa est supprimé ;</br>
	<br>2° Le paragraphe 25.4 est ainsi rédigé : « Sans objet. » ;</br>
	<br>3° Les paragraphes 25.4.1 et 25.4.2 sont supprimés ;</br>
	<br>4° Le paragraphe 25.5 est ainsi rédigé :</br>
	<br>« 25.5. Evolution des tarifs après la mise en service.</br>
	<br>« Les tarifs de péage appliqués aux véhicules de la classe 1 sont révisés au 1er février de chaque année suivant l'année N, N étant la première année civile comportant plus de trois mois d'exploitation de l'autoroute.</br>
	<br>« Ces tarifs de péage sont révisés selon les modalités suivantes :</br>
 </p>
 <p align="left">
	<br> «- la 13e année suivant l'année N (n=N+13) :</br>
 </p>
 <p align="left">
	<br>« Les Taux Kilométriques Individuels de référence TKIref sont les suivants :</br>
 </p>
 <p align="left">
	<div align="center">
	   <center>
		  <table border="1">...</table>
	   </center>
	</div>
 </p>
 <p align="left">
	<br>« Pour toute classe de véhicule a et trajet t :</br>
	<br>« TKIa t n = TKIref a t * max (In-1 / In-2 ; 1)*ECna</br>
	<br>« TKIAa t n &lt;= TKI a t n</br>
	<br>« où ECna est égal à 1 pour la classe 1 et 1,01 pour les classes 2, 3, 4 et 5.</br>
 </p>
 <p align="left">
	<br> «- à compter de la 14e année suivant l'année N (n &gt;= N+14) :</br>
 </p>
 <p align="left">
	<br>« Pour toute classe de véhicule a et trajet t :</br>
	<br>« TKI a t n = TKI a t n-1 * max (In-1 / In-2 + Cad ; 1)* ECna</br>
	<br>« TKIAa t n &lt;= TKI a t n</br>
	<br>« TKIAa t n &lt;= TKIAa t n-1 * max (In-1 / In-2 + Cad + 0,01 ; 1)* ECna</br>
	<br>« Le coefficient Cad prend les valeurs suivantes :</br>
 </p>
 <p align="left">
	<div align="center">
	   <center>
		  <table border="1">...</table>
	   </center>
	</div>
 </p>
 <p align="left">
	<br>« Le coefficient ECna prend les valeurs suivantes :</br>
 </p>
 <p align="left">
	<div align="center">
	   <center>
		  <table border="1">...</table>
	   </center>
	</div>
 </p>
 <p align="left">
	<br>« Le TKMP de l'année n est égal à la somme des produits des TKI1 n de chaque trajet par la distance tarifaire dudit trajet, divisée par la somme des distances tarifaires.</br>
	<br>« où :</br>
	<br>« N est défini au premier alinéa de l'article 25.5 ;</br>
	<br>« TKIAa t n est égal au tarif (en €HT/km) de la classe de véhicule a et du trajet t, applicable du 1er février de l'année n au 31 janvier de l'année n + 1 inclus divisé par la distance tarifaire (en kilomètre) du trajet t, définie à l'annexe 22 ;</br>
	<br>TKIa t n est la valeur (en €HT/km) maximale que peut prendre le TKIA de la classe de véhicule a et du trajet t, applicable du 1er février de l'année n au 31 janvier de l'année n + 1 inclus ;</br>
	<br>« In est l'indice des prix français à la consommation hors tabac pour le mois d'octobre de l'année n. » ;</br>
	<br>5° Les paragraphes 25.5.1 et 25.5.2 sont supprimés.</br>
 </p>
</ARTICLE_TEXTE>
```


---

### CAS-007: Rectificatif (NOR se terminant par Z, F ou H)
(<em class="cas">Journal officiel n° 0007 du 9 janvier 2022, texte n° 37</em>)

tag:  <em class="tag">CORPS / TEXTE_NON_STRUCTURE</em>

file: 20220111-001501/JOP20220008_012.xml

```text
<p align="left">
	<br>Rectificatif au Journal officiel n° 0007 du 9 janvier 2022, texte n° 37 :</br>
	<br>Dans le titre et au premier alinéa, au lieu de : « 7 janvier 2021 », lire : « 7 janvier 2022 ».</br>
</p>
```

---

### CAS-xxx: Texte non structuré dans le CORPS

tag:  <em class="tag">CORPS/TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220327-001502/JOP20220073_018.xml](../resources/data-full/jorf/2022/20220327-001502/JOP20220073_018.xml)

Acte du JORF: [Ordonnance n° 2021-1843 du 22 décembre 2021 portant partie législative du code des impositions sur les biens et services et transposant diverses normes du droit de l'Union européenne (rectificatif)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045412285?init=true) (NOR: ECOE2120672Z) (JORF n° 0073 du 27 mars 2022)

Modifications portant sur :
- [Ordonnance n° 2021-1843 du 22 décembre 2021 portant partie législative du code des impositions sur les biens et services et transposant diverses normes du droit de l'Union européenne](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044590225) (NOR: ECOE2120672R) (JORF n° 0302 du 29 décembre 2021)
- [Code des impositions sur les biens et services](https://www.legifrance.gouv.fr/codes/texte_lc/LEGITEXT000044595989/?isSuggest=true)

Remarques :  
- Pas de version consolidée de l'ordonnance publiée au JORF n° 0073 du 27 mars 2022.
- Pas de version consolidée de l'ordonnance publiée au JORF n° 0302 du 29 décembre 2021, c'est la version initiale de l'ordonnance elle-même qui est rectifiée.
- La rectification sur le code des impositions sur les biens et services ne produit pas de nouvelle version (mort né ?) (ex. : [Article L422-51](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044602645?isSuggest=true))
- Idem dans le code de la sécurité intérieure (ex. : [Article L742-11-2](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000046013836))

Questions :
- Dans <i>p) Dans la section 4 du chapitre II du titre II du livre IV :</i> si l'on doit créer des liens sur les numéros d'articles, quelles sont leurs cibles ? Les articles dans l'annexe  de l'ordonnance ou dans le code ?

---

### CAS-xxx: Rectificatif

tag:  <em class="tag">CORPS / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220111-001501/JOP20220008_012.xml](../resources/data-full/jorf/2022/20220111-001501/JOP20220008_012.xml)

Acte du JORF: [Décret du 7 janvier 2021 portant nomination (Cour des comptes) (rectificatif)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044901840?init=true)

Modifications portant sur :
- [Décret du 7 janvier 2022 portant nomination (Cour des comptes)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044890825)

```text
<p align="left">
    <br>Rectificatif au Journal officiel n° 0007 du 9 janvier 2022, texte n° 37 :</br>
    <br>Dans le titre et au premier alinéa, au lieu de : « 7 janvier 2021 », lire : « 7 janvier 2022 ».</br>
</p>
```

Questions :  
Question 1 : pas de version consolidée ?  
Question 2 : rectificatif => texte initial modifié sans création d'une nouvelle version ?  

---

### CAS-xxx: Articles modifiants dans CORPS > TEXTE_NON_STRUCTURE 

tag:  <em class="tag">CORPS / TEXTE_NON_STRUCTURE</em>

file: [jorf/2022/20220318-001502/JOP20220065_002.xml](../resources/data-full/jorf/2022/20220318-001502/JOP20220065_002.xml)

Acte du JORF: [Avenant n° 1 du 17 mars 2022 à la convention du 2 juin 2021 entre l'Etat, l'Agence nationale de la recherche et la Caisse des dépôts et consignations relative au programme d'investissements d'avenir (action « Financement structurel de l'écosystème de l'éducation, de l'enseignement supérieur, de l'innovation et de la valorisation »)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000045373271?init=true)

Modifications portant sur :
- [Convention du 2 juin 2021 entre l'Etat, l'Agence nationale de la recherche et la Caisse des dépôts et consignations relative au programme d'investissements d'avenir (action « Financement structurel de l'écosystème de l'éducation, de l'enseignement supérieur, de l'innovation et de la valorisation »)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000043590435)

```text
<p align="center">
    <br>Article 2</br>
    <br>Modification de l'article 1.1 « Cadre budgétaire »</br>
</p>
<p align="left">
    <br>L'article 1.1 est modifié comme suit :</br>
    ...
</p>
```

Commentaire :  
Le texte sur lequel portent les modifications n'est pas structuré, les articles ciblés n'ont pas de CID.