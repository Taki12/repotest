package fr.dila.theiaapi;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.dila.theiaapi.models.pivot.AnnotatorPivotDto;
import fr.dila.theiaapi.models.pivot.PythagoriaLienCitationSelectorDto;
import fr.dila.theiaapi.services.AnnotatorServiceImpl;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ResourceLoader;

import javax.xml.transform.TransformerException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertFalse;

@SpringBootTest
@Log4j2
class TestAnnotationInsertion {

	private static final String XSLT_CLEAN_THEIA_TAGGED = "classpath:xslt/test01-clean-theia-tagged.xsl";
	private static final String DATA_JSON_PIVOT_FOLDER = "json-pivot";
	private static final String DATA_OUT_FOLDER = "data-out";
	private final Path testResourcesDirectory = Paths.get("src","test","resources");
	private final ObjectMapper objectMapper = new ObjectMapper();
	private final AnnotatorServiceImpl annotatorService;
	private final ResourceLoader resourceLoader;

	TestAnnotationInsertion(
			@Autowired
			AnnotatorServiceImpl annotatorService,
			@Autowired
			ResourceLoader resourceLoader
	) {
		this.annotatorService = annotatorService;
		this.resourceLoader = resourceLoader;
	}

	@Test
	void check() throws IOException, TransformerException {

		final File testJsonPivotFile = testResourcesDirectory.resolve(DATA_JSON_PIVOT_FOLDER).resolve("JUSC0818602A-visa-art3.json").toFile();
		final AnnotatorPivotDto annotatorPivotDto = objectMapper.readValue(testJsonPivotFile, AnnotatorPivotDto.class);

		// .
//		final byte[] xmlToAnnotate = Base64.getDecoder().decode(annotatorPivotDto.getXmlBase64());
//		final Path xmlToAnnotatePath = testResourcesDirectory.resolve(DATA_OUT_FOLDER).resolve("xml-to-annotate.xml");
//		FileUtils.copyInputStreamToFile(new ByteArrayInputStream(xmlToAnnotate), xmlToAnnotatePath.toFile());

		// .
//		final byte[] annotationsToMerge = new XmlMapper().writeValueAsBytes(annotatorPivotDto.getLegalText());
//		final Path annotationsToMergePath = testResourcesDirectory.resolve(DATA_OUT_FOLDER).resolve("annotations-to-insert.xml");
//		FileUtils.copyInputStreamToFile(new ByteArrayInputStream(annotationsToMerge), annotationsToMergePath.toFile());


		final byte[] result = annotatorService.insertLinkAnnotations(annotatorPivotDto);
		final Path resultPath = testResourcesDirectory.resolve(DATA_OUT_FOLDER).resolve("result.xml");
		FileUtils.copyInputStreamToFile(new ByteArrayInputStream(result), resultPath.toFile());

		assertFalse(false);
	}
}
