package fr.dila.theiaapi;

import fr.dila.theiaapi.helpers.XmlHelper;
import fr.dila.theiaapi.services.AnnotatorServiceImpl;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertFalse;

@SpringBootTest
@Log4j2
class TestCheckIfNewTextToConsider {

	private static final String XSLT_CLEAN_THEIA_TAGGED = "classpath:xslt/test01-clean-theia-tagged.xsl";
	private static final String DATA_SAMPLE_FOLDER = "data-full";
	private static final String DATA_ERROR_FOLDER = "data-error";
	private final Path testResourcesDirectory = Paths.get("src","test","resources");
	private final AnnotatorServiceImpl annotatorService;
	private final ResourceLoader resourceLoader;

	TestCheckIfNewTextToConsider(
			@Autowired
			AnnotatorServiceImpl annotatorService,
			@Autowired
			ResourceLoader resourceLoader
	) {
		this.annotatorService = annotatorService;
		this.resourceLoader = resourceLoader;
	}

	@Test
	void check() throws IOException {

		final String testJorfXmlFolderPath = testResourcesDirectory.resolve(DATA_SAMPLE_FOLDER).resolve("jorf").toFile().getAbsolutePath();
		final AtomicBoolean stillTextToCondider = new AtomicBoolean(false);

		try (Stream<Path> stream = Files.walk(Paths.get(testJorfXmlFolderPath))) {
			stream.filter(Files::isRegularFile)
					.forEach(jorfXmlFilePath -> {
						try {
							if (stillTextToCondider(jorfXmlFilePath)) {
								stillTextToCondider.set(true);
								log.warn(jorfXmlFilePath);
							}
						} catch (TransformerException | IOException | SAXException | ParserConfigurationException e) {
							log.error(jorfXmlFilePath);
						}
					});
		}

		assertFalse(stillTextToCondider.get());
	}

	private boolean stillTextToCondider(final Path jorfXmlFilePath) throws IOException, TransformerException, ParserConfigurationException, SAXException {

		final byte[] xmlTheiaPrepared = annotatorService.jorfXmlPrepare(new FileInputStream(jorfXmlFilePath.toFile()));
		final byte[] xmlTheiaCleaned = XmlHelper.xmlTransform(xmlTheiaPrepared, resourceLoader.getResource(XSLT_CLEAN_THEIA_TAGGED).getInputStream());
		Document doc = convertBytesToXMLDocument(xmlTheiaCleaned);
		final String text = doc.getDocumentElement().getTextContent();
		if (StringUtils.hasText(text)) {
			final Path errorPath = testResourcesDirectory.resolve(DATA_ERROR_FOLDER).resolve(testResourcesDirectory.resolve(DATA_SAMPLE_FOLDER).toAbsolutePath().relativize(jorfXmlFilePath));
			FileUtils.copyInputStreamToFile(new ByteArrayInputStream(xmlTheiaCleaned), errorPath.toFile());
			return true;
		}
		return false;
	}

	private Document convertBytesToXMLDocument(byte[] xmlData) throws IOException, SAXException, ParserConfigurationException {
		//Parser that produces DOM object trees from XML content
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		//API to obtain DOM Document instance
		DocumentBuilder builder = factory.newDocumentBuilder();

		//Parse the content to Document object
		return builder.parse(new ByteArrayInputStream(xmlData));
	}
}
