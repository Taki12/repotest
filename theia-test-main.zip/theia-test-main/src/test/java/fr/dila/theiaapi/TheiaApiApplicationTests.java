package fr.dila.theiaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheiaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
